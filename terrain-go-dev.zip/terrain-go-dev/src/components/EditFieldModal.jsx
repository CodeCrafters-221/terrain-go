import React, { useState, useEffect } from 'react';
import { useDashboard } from '../context/DashboardContext';
import { toast } from 'react-toastify';
import { supabase } from '../services/supabaseClient';
import { AvailabilityService } from '../services/AvailabilityService';
import { Camera, Trash2, Plus, Pencil } from "lucide-react";

const DAYS = [
    { value: 1, label: "Lundi" },
    { value: 2, label: "Mardi" },
    { value: 3, label: "Mercredi" },
    { value: 4, label: "Jeudi" },
    { value: 5, label: "Vendredi" },
    { value: 6, label: "Samedi" },
    { value: 0, label: "Dimanche" },
];

const EditFieldModal = () => {
    const { updateField, closeEditModal, isEditModalOpen, editingField, uploadMultipleFieldImages, deleteFieldImage } = useDashboard();

    // Form State
    const [formData, setFormData] = useState({
        name: "",
        type: "",
        location: "",
        price: "",
        description: "",
        hours: "",
        image: ""
    });

    // Availability schedule state
    const [schedule, setSchedule] = useState(
        DAYS.map(d => ({
            day_of_week: d.value,
            label: d.label,
            enabled: false,
            start_time: "08:00",
            end_time: "00:00",
        }))
    );

    const [isLoading, setIsLoading] = useState(false);
    const [isUploadingImage, setIsUploadingImage] = useState(false);
    const [fieldImages, setFieldImages] = useState([]);
    const [replacingImageUrl, setReplacingImageUrl] = useState(null);
    const fileInputRef = React.useRef(null);

    const updateScheduleDay = (index, field, value) => {
        setSchedule(prev => {
            const updated = [...prev];
            updated[index] = { ...updated[index], [field]: value };
            return updated;
        });
    };

    const handleReplaceImageTrigger = (imageUrl) => {
        setReplacingImageUrl(imageUrl);
        fileInputRef.current?.click();
    };

    const handleAddImage = async (e) => {
        const files = e.target.files;
        if (!files || files.length === 0) return;

        setIsUploadingImage(true);
        try {
            if (replacingImageUrl) {
                // Replacement Logic
                await deleteFieldImage(editingField.id, replacingImageUrl);
                const urls = await uploadMultipleFieldImages(editingField.id, files);
                const newImages = urls.map((url) => ({ url_image: url }));

                setFieldImages((prev) => {
                    const index = prev.findIndex(
                        (img) => img.url_image === replacingImageUrl,
                    );
                    if (index === -1) return [...prev, ...newImages];
                    const updated = [...prev];
                    updated.splice(index, 1, ...newImages);
                    return updated;
                });

                toast.success("Image remplacée !");
            } else {
                // Normal Add Logic
                const urls = await uploadMultipleFieldImages(editingField.id, files);
                const newImages = urls.map((url) => ({ url_image: url }));
                setFieldImages((prev) => [...prev, ...newImages]);
                toast.success(
                    files.length > 1
                        ? `${files.length} images ajoutées !`
                        : "Image ajoutée !",
                );
            }
        } catch (error) {
            toast.error(
                replacingImageUrl
                    ? "Erreur lors du remplacement"
                    : "Erreur lors de l'ajout des images",
            );
        } finally {
            setIsUploadingImage(false);
            setReplacingImageUrl(null);
            if (fileInputRef.current) fileInputRef.current.value = "";
        }
    };

    const handleDeleteImage = async (imageUrl) => {
        if (!window.confirm("Supprimer cette image ?")) return;

        try {
            await deleteFieldImage(editingField.id, imageUrl);
            setFieldImages((prev) => prev.filter((img) => img.url_image !== imageUrl));
            toast.success("Image supprimée !");
        } catch (error) {
            toast.error("Erreur lors de la suppression");
        }
    };

    // Initialize form and fetch availability
    useEffect(() => {
        if (editingField) {
            let priceValue = editingField.price;
            if (typeof editingField.price === 'string') {
                priceValue = editingField.price.replace(/[^0-9]/g, '');
            }

            setFormData({
                ...editingField,
                price: priceValue
            });

            // Set images from field data
            if (editingField.field_images) {
                setFieldImages(editingField.field_images);
            } else if (
                editingField.image &&
                !editingField.image.includes("placehold.co")
            ) {
                setFieldImages([{ url_image: editingField.image }]);
            }

            // Fetch existing availability
            const fetchAvailability = async () => {
                try {
                    const availabilities = await AvailabilityService.getFieldAvailability(editingField.id);

                    // Map existing availabilities to our schedule state
                    setSchedule(prev => prev.map(day => {
                        const found = availabilities.find(a => a.day_of_week === day.day_of_week);
                        if (found) {
                            return {
                                ...day,
                                enabled: true,
                                start_time: found.start_time.substring(0, 5),
                                end_time: found.end_time.substring(0, 5)
                            };
                        }
                        return { ...day, enabled: false };
                    }));
                } catch (error) {
                    console.error("Erreur chargement disponibilités:", error);
                }
            };

            fetchAvailability();
        }
    }, [editingField]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);

        // Simple validation
        if (!formData.name || !formData.price || !formData.location) {
            toast.error("Veuillez remplir les champs obligatoires");
            setIsLoading(false);
            return;
        }

        // Check if at least 1 day is enabled
        const enabledDays = schedule.filter(d => d.enabled);
        if (enabledDays.length === 0) {
            toast.error("Veuillez activer au moins un jour de disponibilité.");
            setIsLoading(false);
            return;
        }

        try {
            // Générer un résumé des horaires
            const activeDays = schedule.filter(d => d.enabled);
            let hoursSummary = "Fermé";
            if (activeDays.length > 0) {
                hoursSummary = `${activeDays[0].start_time} - ${activeDays[0].end_time}`;
            }

            // Format data for Context
            const updatedField = {
                ...formData,
                hours: hoursSummary,
                price: `${formData.price} CFA/h`, // Re-format price
                skipImageUpdate: true, // Don't let updateField overwrite our gallery
            };

            await updateField(editingField.id, updatedField);

            // Update availabilities
            const availabilities = enabledDays.map(d => ({
                day_of_week: d.day_of_week,
                start_time: d.start_time,
                end_time: d.end_time,
            }));

            await AvailabilityService.setFieldAvailability(editingField.id, availabilities);

            toast.success("Terrain et disponibilités modifiés avec succès !");
            closeEditModal();
        } catch (error) {
            console.error("Erreur modification:", error);
            toast.error("Une erreur est survenue lors de la modification.");
        } finally {
            setIsLoading(false);
        }
    };

    const inputClasses = "w-full px-4 py-3 rounded-lg border border-surface-highlight bg-background-dark text-text-secondary placeholder-text-muted focus:outline-none focus:border-primary-new transition-colors";
    const labelClasses = "text-white text-sm font-medium mb-1 block";

    if (!isEditModalOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-surface-dark rounded-2xl border border-surface-highlight w-full max-w-2xl max-h-[90vh] overflow-y-auto relative shadow-[0_0_40px_rgba(0,0,0,0.5)]">

                {/* Header */}
                <div className="flex items-center justify-between p-6 border-b border-surface-highlight sticky top-0 bg-surface-dark z-10">
                    <div className="flex flex-col">
                        <h2 className="text-white text-2xl font-bold">Modifier le Terrain</h2>
                        <p className="text-text-secondary text-xs">Mettez à jour les informations et disponibilités</p>
                    </div>
                    <button onClick={closeEditModal} className="text-text-secondary hover:text-white transition-colors">
                        <span className="material-symbols-outlined">close</span>
                    </button>
                </div>

                {/* Body */}
                <div className="p-6">
                    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
                        {/* Name */}
                        <div>
                            <label htmlFor="name" className={labelClasses}>Nom du terrain *</label>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                placeholder="Ex: Terrain Almadies 2"
                                value={formData.name}
                                onChange={handleInputChange}
                                className={inputClasses}
                                required
                            />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Type */}
                            <div>
                                <label htmlFor="type" className={labelClasses}>Type de terrain</label>
                                <select
                                    id="type"
                                    name="type"
                                    value={formData.type}
                                    onChange={handleInputChange}
                                    className={inputClasses}
                                >
                                    <option value="">Choisir...</option>
                                    <option value="5 vs 5 • Gazon synthétique">5 vs 5 • Gazon synthétique</option>
                                    <option value="7 vs 7 • Gazon synthétique">7 vs 7 • Gazon synthétique</option>
                                    <option value="5 vs 5 • Gazon naturel">5 vs 5 • Gazon naturel</option>
                                    <option value="7 vs 7 • Gazon naturel">7 vs 7 • Gazon naturel</option>
                                </select>
                            </div>

                            {/* Price */}
                            <div>
                                <label htmlFor="price" className={labelClasses}>Prix / Heure (CFA) *</label>
                                <input
                                    type="number"
                                    id="price"
                                    name="price"
                                    placeholder="Ex: 25000"
                                    value={formData.price}
                                    onChange={handleInputChange}
                                    className={inputClasses}
                                    required
                                />
                            </div>
                        </div>

                        {/* Location */}
                        <div>
                            <label htmlFor="location" className={labelClasses}>Adresse / Localisation *</label>
                            <input
                                type="text"
                                id="location"
                                name="location"
                                placeholder="Ex: Mermoz, Pyrotechnie"
                                value={formData.location}
                                onChange={handleInputChange}
                                className={inputClasses}
                                required
                            />
                        </div>

                        {/* Description */}
                        <div>
                            <label htmlFor="description" className={labelClasses}>Description</label>
                            <textarea
                                id="description"
                                name="description"
                                rows="3"
                                placeholder="Description du terrain, commodités..."
                                value={formData.description}
                                onChange={handleInputChange}
                                className={inputClasses}
                            />
                        </div>

                        {/* ═══ SECTION GALERIE PHOTOS ═══ */}
                        <div className="border-t border-surface-highlight pt-6">
                            <div className="flex items-center justify-between mb-4">
                                <div>
                                    <h3 className="text-white text-lg font-bold mb-1">
                                        📸 Galerie Photos
                                    </h3>
                                    <p className="text-text-secondary text-xs">
                                        Gérez les photos du terrain (Sélection multiple possible).
                                    </p>
                                </div>
                                <button
                                    type="button"
                                    onClick={() => fileInputRef.current?.click()}
                                    disabled={isUploadingImage}
                                    className="flex items-center gap-2 bg-primary-new/10 text-primary-new border border-primary-new/30 px-4 py-2 rounded-xl text-sm font-bold hover:bg-primary-new/20 transition-all disabled:opacity-50"
                                >
                                    {isUploadingImage ? (
                                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary-new"></div>
                                    ) : (
                                        <Plus className="w-4 h-4" />
                                    )}
                                    Ajouter des photos
                                </button>
                                <input
                                    type="file"
                                    ref={fileInputRef}
                                    onChange={handleAddImage}
                                    accept="image/*"
                                    multiple
                                    className="hidden"
                                />
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                                {fieldImages.map((img, idx) => (
                                    <div
                                        key={idx}
                                        className="relative group aspect-video rounded-xl overflow-hidden border border-surface-highlight"
                                    >
                                        <img
                                            src={img.url_image}
                                            alt={`Terrain ${idx + 1}`}
                                            className="w-full h-full object-cover"
                                        />
                                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                            <button
                                                type="button"
                                                onClick={() => handleReplaceImageTrigger(img.url_image)}
                                                className="bg-primary-new text-background-dark p-2 rounded-full hover:bg-primary-new/80 transition-colors shadow-lg"
                                                title="Modifier/Remplacer"
                                            >
                                                <Pencil className="w-4 h-4" />
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => handleDeleteImage(img.url_image)}
                                                className="bg-red-500 text-white p-2 rounded-full hover:bg-red-600 transition-colors shadow-lg"
                                                title="Supprimer"
                                            >
                                                <Trash2 className="w-4 h-4" />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                                {fieldImages.length === 0 && !isUploadingImage && (
                                    <div className="col-span-full py-8 flex flex-col items-center justify-center border border-dashed border-surface-highlight rounded-xl bg-background-dark/50">
                                        <Camera className="w-8 h-8 text-text-muted mb-2" />
                                        <p className="text-text-secondary text-sm">
                                            Aucune photo dans la galerie
                                        </p>
                                    </div>
                                )}
                                {isUploadingImage && (
                                    <div className="aspect-video rounded-xl border border-dashed border-primary-new bg-primary-new/5 flex items-center justify-center">
                                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-new"></div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* ═══ SECTION DISPONIBILITÉS ═══ */}
                        <div className="border-t border-surface-highlight pt-6">
                            <h3 className="text-white text-lg font-bold mb-1">📅 Disponibilités</h3>
                            <p className="text-text-secondary text-xs mb-4">Définissez les jours et heures d'ouverture du terrain.</p>

                            <div className="space-y-3">
                                {schedule.map((day, index) => (
                                    <div
                                        key={day.day_of_week}
                                        className={`flex items-center gap-2 sm:gap-3 p-2 sm:p-3 rounded-xl border transition-all ${day.enabled
                                            ? "bg-background-dark border-primary-new/40"
                                            : "bg-background-dark/50 border-surface-highlight/50 opacity-60"
                                            }`}
                                    >
                                        {/* Checkbox */}
                                        <div className="flex items-center justify-center w-6 sm:w-10 shrink-0">
                                            <input
                                                type="checkbox"
                                                checked={day.enabled}
                                                onChange={(e) => updateScheduleDay(index, 'enabled', e.target.checked)}
                                                className="w-4 h-4 sm:w-5 sm:h-5 rounded border-surface-highlight text-primary-new focus:ring-primary-new cursor-pointer accent-primary-new bg-surface-dark"
                                            />
                                        </div>

                                        {/* Day name */}
                                        <span className={`text-[11px] sm:text-sm font-semibold w-16 sm:w-20 shrink-0 ${day.enabled ? 'text-white' : 'text-text-muted'
                                            }`}>
                                            {day.label}
                                        </span>

                                        {/* Time inputs */}
                                        {day.enabled && (
                                            <div className="flex items-center gap-1 sm:gap-2 flex-1 justify-end">
                                                <input
                                                    type="time"
                                                    value={day.start_time}
                                                    onChange={(e) => updateScheduleDay(index, 'start_time', e.target.value)}
                                                    className="px-1 sm:px-2 py-1 sm:py-1.5 rounded-lg bg-surface-dark text-white text-[11px] sm:text-sm border border-surface-highlight focus:border-primary-new focus:outline-none w-[68px] sm:w-28 text-center"
                                                />
                                                <span className="text-text-secondary text-[10px] sm:text-xs">à</span>
                                                <input
                                                    type="time"
                                                    value={day.end_time}
                                                    onChange={(e) => updateScheduleDay(index, 'end_time', e.target.value)}
                                                    className="px-1 sm:px-2 py-1 sm:py-1.5 rounded-lg bg-surface-dark text-white text-[11px] sm:text-sm border border-surface-highlight focus:border-primary-new focus:outline-none w-[68px] sm:w-28 text-center"
                                                />
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Submit Button */}
                        <div className="flex justify-end gap-4 mt-2 pt-4 border-t border-surface-highlight">
                             <button
                                type="button"
                                onClick={closeEditModal}
                                className="px-6 py-3 rounded-xl border border-surface-highlight text-text-secondary hover:bg-surface-highlight hover:text-white transition-colors"
                            >
                                Annuler
                            </button>
                            <button
                                type="submit"
                                disabled={isLoading || isUploadingImage}
                                className="bg-primary-new text-background-dark px-8 py-3 rounded-xl font-bold hover:shadow-[0_0_20px_rgba(242,127,13,0.5)] transition-all disabled:opacity-50"
                            >
                                {isLoading ? "Enregistrement..." : "Enregistrer les modifications"}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default EditFieldModal;

